"""Lecture des messages MQTT des équipements (F18.1, CA-18.1, CA-18.5, D255, D256).

Chaque message devient des relevés typés, validés sur des plages physiques, horodatés en UTC. Un message illisible ou
hors plage est écarté et compté, jamais écrit. Date absente ou incohérente (±24 h de l'horloge de l'agent) : heure de
réception, qualité ``ESTIMATED`` ; horloge de l'agent non synchronisée : qualité ``ESTIMATED`` aussi (D256).
"""

from __future__ import annotations

import datetime as dt
import json
import math
from dataclasses import dataclass

RANGES = {
    "power_w": (-1_000_000, 1_000_000, "W"),
    "current_a": (-5_000, 5_000, "A"),
    "voltage_v": (0, 1_000, "V"),
    "energy_total_wh": (0, 1e12, "Wh"),
    "energy_wh": (0, 99_999_999, "Wh"),
    "power_factor": (-1, 1, ""),
    "soc_pct": (0, 100, "%"),
    "power_charge_w": (0, 1_000_000, "W"),
    "power_discharge_w": (0, 1_000_000, "W"),
    "temperature_c": (-40, 120, "°C"),
    "irradiance_w_m2": (0, 2_000, "W/m²"),
    "wind_speed_m_s": (0, 100, "m/s"),
    "humidity_pct": (0, 100, "%"),
    "rain_mm": (0, 500, "mm"),
    # Linky (TIC, E172) : puissance apparente et production, gardées en local (le cloud ne les reçoit pas agrégées).
    "apparent_power_va": (0, 1_000_000, "VA"),
    "apparent_power_injected_va": (0, 1_000_000, "VA"),
    "energy_injected_total_wh": (0, 1e12, "Wh"),
}


@dataclass(frozen=True)
class Reading:
    source: str  # device | battery | weather
    ref: int | None  # device_id, stock_id, ou None pour la météo
    data_type: str
    value: float
    at: dt.datetime
    quality: str = "OK"

    @property
    def device_key(self) -> str:
        return {
            "device": f"device:{self.ref}",
            "battery": f"stock:{self.ref}",
            "weather": "weather",
        }[self.source]

    @property
    def unit(self) -> str:
        return RANGES[self.data_type][2]


class ParseError(ValueError):
    pass


def _json(payload: bytes) -> dict:
    if len(payload) > 16_384:
        raise ParseError("message trop volumineux")
    try:
        data = json.loads(payload.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ParseError("JSON illisible") from exc
    if not isinstance(data, dict):
        raise ParseError("objet JSON attendu")
    return data


def _when(value: object, received: dt.datetime, clock_synced: bool) -> tuple[dt.datetime, str]:
    quality = "OK" if clock_synced else "ESTIMATED"
    at: dt.datetime | None = None
    if isinstance(value, (int, float)) and math.isfinite(value) and value > 0:
        at = dt.datetime.fromtimestamp(float(value), tz=dt.timezone.utc)
    elif isinstance(value, str):
        try:
            at = dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
            if at.tzinfo is None:
                at = None
        except ValueError:
            at = None
    # Passé d'un jour au plus, futur de 5 minutes au plus (la tolérance du cloud) : au-delà, datée à la réception. Un horodatage
    # en avance figerait le SoC local plusieurs heures (audit B18-2).
    if at is None or (received - at).total_seconds() > 86_400 or (at - received).total_seconds() > 300:
        return received, "ESTIMATED"
    return at.astimezone(dt.timezone.utc), quality


def _number(data: dict, key: str) -> float | None:
    v = data.get(key)
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
        return None
    return float(v)


def _readings(
    source: str,
    ref: int | None,
    values: dict[str, float | None],
    at: dt.datetime,
    quality: str,
) -> list[Reading]:
    out = []
    for key, v in values.items():
        if v is None:
            continue
        lo, hi, _ = RANGES[key]
        if not lo <= v <= hi:
            raise ParseError(f"{key} hors plage physique ({v})")
        out.append(Reading(source, ref, key, v, at, quality))
    if not out:
        raise ParseError("aucune grandeur reconnue")
    return out


def shelly_gen2(device_id: int, payload: bytes, received: dt.datetime, clock_synced: bool = True) -> list[Reading]:
    """Statut natif Shelly Gen2 (``<id>/status/switch:0``, ``em:0``, ``pm1:0``) : apower, voltage, current, aenergy.total."""
    data = _json(payload)
    energy = data.get("aenergy") if isinstance(data.get("aenergy"), dict) else {}
    # ``aenergy.minute_ts`` date le début de la dernière minute du compteur, pas la puissance instantanée : un statut Shelly
    # est publié au changement, il est daté à sa réception (précision < 1 s sur horloge synchronisée, CA-18.5).
    at, quality = received, ("OK" if clock_synced else "ESTIMATED")
    values = {
        "power_w": _number(data, "apower") if "apower" in data else _number(data, "act_power"),
        "voltage_v": _number(data, "voltage"),
        "current_a": _number(data, "current"),
        "energy_total_wh": _number(energy, "total") if energy else None,
        "power_factor": _number(data, "pf"),
    }
    return _readings("device", device_id, values, at, quality)


def h2s_device(device_id: int, payload: bytes, received: dt.datetime, clock_synced: bool = True) -> list[Reading]:
    """Format JSON H2S d'une passerelle : power_w, current_a, voltage_v, energy_wh, power_factor. PowerLogic et Linky se lisent aussi
    directement (``modbus``, ``tic``, E172)."""
    data = _json(payload)
    at, quality = _when(data.get("timestamp"), received, clock_synced)
    values = {
        k: _number(data, k)
        for k in (
            "power_w",
            "current_a",
            "voltage_v",
            "energy_wh",
            "energy_total_wh",
            "power_factor",
        )
    }
    return _readings("device", device_id, values, at, quality)


def h2s_battery(stock_id: int, payload: bytes, received: dt.datetime, clock_synced: bool = True) -> list[Reading]:
    """État batterie au format H2S (``/battery/status``) : soc, puissances de charge et décharge, tension, température."""
    data = _json(payload)
    at, quality = _when(data.get("timestamp"), received, clock_synced)
    values = {
        "soc_pct": _number(data, "soc") if "soc" in data else _number(data, "soc_pct"),
        "power_charge_w": _number(data, "power_charge_w"),
        "power_discharge_w": _number(data, "power_discharge_w"),
        "voltage_v": _number(data, "voltage_v"),
        "current_a": _number(data, "current_a"),
        "temperature_c": _number(data, "temperature_c"),
    }
    return _readings("battery", stock_id, values, at, quality)


def h2s_weather(payload: bytes, received: dt.datetime, clock_synced: bool = True) -> list[Reading]:
    data = _json(payload)
    at, quality = _when(data.get("timestamp"), received, clock_synced)
    values = {
        k: _number(data, k)
        for k in (
            "temperature_c",
            "irradiance_w_m2",
            "wind_speed_m_s",
            "humidity_pct",
            "rain_mm",
        )
    }
    return _readings("weather", None, values, at, quality)
