"""Agent local H2S (brique 18) : exécutant des décisions du cloud, collecte, buffer, fédéré borné.

Voir specs/analyse/BRIQUE-18-PLAN.md (D247 à D257).
"""

__version__ = "1.1.0"
