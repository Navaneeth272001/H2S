# Déploiement de l'agent local sur un boîtier

> **Non vérifié sur matériel.** Aucun Raspberry Pi, module TPM 2.0, prise Shelly ni batterie Jackery n'était disponible
> en recette. Ce guide décrit la cible ; seules les étapes marquées ✅ ont été exécutées (sur poste Linux, avec un
> broker MQTT et des équipements simulés). Voir D254 et D255.

## 0. Côté cloud

Le backend exige `H2S_EDGE_SIGNING_SEED` (graine Ed25519 des ordres, `openssl rand -base64 32`) et
`H2S_EDGE_GRADIENT_KEY` (clé RSA 2048 bits PKCS#8 en base64) ; génération et conséquences d'un changement dans
`.env.example`. Changer l'une ou l'autre impose de réenrôler tous les boîtiers.

## 1. Système

- Raspberry Pi OS Lite 64 bits (bookworm), mises à jour automatiques de sécurité (`unattended-upgrades`).
- SSH par clé seulement, pas de mot de passe ; pare-feu `nftables` : entrée SSH depuis le VPN d'exploitation, rien
  d'autre ; sortie HTTPS vers le cloud H2S et NTP.
- Horloge : `systemd-timesyncd` actif. L'agent refuse d'exécuter un ordre hors de sa fenêtre de validité et le cloud
  refuse toute requête décalée de plus de 5 minutes (D256).
- Partition de données chiffrée **LUKS2** montée sur `/var/lib/h2s-agent` et `/var/lib/postgresql`. Déverrouillage
  par TPM 2.0 (`systemd-cryptenroll --tpm2-device=auto --tpm2-pcrs=7`) : *non vérifié*.

## 2. Base locale ✅ (poste Linux)

```sh
apt install postgresql-16 postgresql-client-16
sudo -u postgres createuser h2s_agent && sudo -u postgres createdb -O h2s_agent h2s_agent
```

Connexion par socket Unix (`peer`), sans mot de passe. Le client `pg_dump` doit être de la même version majeure que le
serveur, sinon la sauvegarde quotidienne échoue et lève `BACKUP_FAILED` (constaté en recette : client 14, serveur 16).

## 3. Agent ✅ (poste Linux)

Sur le **poste de publication** d'abord, jamais sur le boîtier : signer le paquet avec la clé de publication, distincte de
la clé des ordres du cloud (D258). La première fois, `--new-key` crée la graine (0600) et affiche la clé publique à
recopier dans `package_public_key` de chaque `agent.json`.

```sh
python3 edge/agent/tools/sign_manifest.py --seed-file /chemin/hors-ligne/cle-publication.seed   # écrit h2s_agent/MANIFEST.json
```

Puis sur le boîtier :

```sh
useradd --system --home /var/lib/h2s-agent --shell /usr/sbin/nologin h2s-agent
install -d -o h2s-agent -m 0700 /var/lib/h2s-agent
install -d -m 0750 -g h2s-agent /etc/h2s-agent
cp -r edge/agent /opt/h2s-agent && python3 -m venv /opt/h2s-agent/venv
/opt/h2s-agent/venv/bin/pip install -r /opt/h2s-agent/requirements.txt
cp deploy/agent.example.json /etc/h2s-agent/agent.json      # adapter équipements, batteries, topics
sudo -u h2s-agent /opt/h2s-agent/venv/bin/python -m h2s_agent enroll --config /etc/h2s-agent/agent.json   # code demandé au clavier
cp deploy/h2s-agent.service /etc/systemd/system/ && systemctl daemon-reload && systemctl enable --now h2s-agent
```

`/opt/h2s-agent` appartient à root et reste en lecture seule pour le service : un paquet modifié est détecté par le
manifeste signé, et le service ne peut pas le réécrire. Sans `package_public_key` ou sans manifeste conforme, l'agent
collecte mais n'exécute aucun ordre (`INTEGRITY_FAILED`). Le manifeste ne couvre ni l'interpréteur ni le venv : un
attaquant maître de la machine le contourne (D254).

Le code d'enrôlement se lit au clavier (`--code` absent) ou dans un fichier (`--code-file`) : passé en argument, il resterait
dans l'historique du shell et visible de `ps`. Un nouveau code du même site annule le précédent ; chaque inscription est
notifiée aux opérateurs et au titulaire du site.

### 3 bis. TPM 2.0, paquet chiffré et paquet sans .py (WP8) — *non vérifié sur boîtier*

- **TPM** : module activé (`dtoverlay=tpm-slb9670`), `apt install libtss2-dev`, `pip install -r requirements-tpm.txt`, utilisateur
  `h2s-agent` dans le groupe `tss`. agent.json : `"key_store": "tpm2"`, `"require_tpm": true` en production. Le service doit voir
  `/dev/tpmrm0` : remplacer `PrivateDevices=true` par `DevicePolicy=closed`, `DeviceAllow=/dev/tpmrm0 rw` et
  `SupplementaryGroups=tss` (et `DeviceAllow=char-ttyUSB rw`, groupe `dialout`, pour la TIC Linky).
  Côté cloud : `H2S_EDGE_TPM_EK_ROOTS` (PEM des AC du fabricant retenu), puis `H2S_EDGE_TPM_REQUIRED=true` et
  `H2S_EDGE_TPM_REQUIRE_ATTESTATION=true` une fois les boîtiers équipés. Sans `H2S_EDGE_TPM_EK_ROOTS`, le backend refuse de
  démarrer avec `H2S_EDGE_TPM_REQUIRED=true` : « TPM exigé » ne se contente jamais d'une déclaration de l'agent.
- **Paquet chiffré** (E177) : sur le poste de publication, `tools/publish_package.py build` produit `app/` (amorce `h2s_boot` +
  `h2s_agent.enc`) ; le technicien lit la clé de code du boîtier (`python -m h2s_boot --config … code-key`, depuis
  `/opt/h2s-agent/app`) ; le poste de publication en tire `package.key` (`publish_package.py wrap`), déposé dans
  `/var/lib/h2s-agent/keys/`. Manifeste signé sur `app/` (`sign_manifest.py --root app`). Service :
  `WorkingDirectory=/opt/h2s-agent/app` et `ExecStart=… python -B -m h2s_boot --config /etc/h2s-agent/agent.json run`. Le code
  de l'agent n'existe en clair qu'en mémoire du processus.
- **Sans .py** (E178) : `tools/build_native.py --out dist/native` sur l'architecture et le Python des boîtiers (Nuitka,
  `requirements-build.txt`, gcc, python3-dev) ; manifeste signé sur `dist/native`.
- Rappel : ni le chiffrement du paquet ni la compilation ne protègent d'un attaquant maître du boîtier en marche ; la partition
  LUKS liée au TPM et Secure Boot restent à mettre en place et à recetter sur le matériel (CA-18.29, CA-18.32).

## 4. Broker MQTT local

`mosquitto.conf` et `mosquitto.acl` : TLS sur le réseau Wi-Fi des équipements, boucle locale pour l'agent, un compte
par équipement (une règle par prise Shelly : `+` n'est un joker que sur un niveau entier), seul l'agent publie les
commandes des batteries et ses propres topics `h2s/site<N>/agent/status` et `h2s/site<N>/agent/errors`.

**Commandes signées (E183, §4.3.5)** : chaque commande publiée sur `<command_prefix>/{charge,discharge,standby}` porte
`alg` (`Ed25519` ou `ECDSA-P256` pour une clé TPM), `key_id` et `signature` (base64url ; r ‖ s sur 64 octets en ECDSA). La
passerelle de la batterie recompose la chaîne canonique — `H2S-COMMAND-V1`, puis `command_id`, `action`, `power_w` à deux
décimales, `duration_s`, `priority`, `timestamp`, `source`, un champ par ligne, séparés par `\n` — et la vérifie avec la clé
publique que l'agent retient sur `h2s/site<N>/agent/pubkey` (`{"algorithm", "public_key", "key_id", "scheme"}`, republiée
toutes les heures). Une commande sans signature valide, ou dont `key_id` diffère de la clé retenue, est ignorée ; une veille
(`standby`) reste la seule commande qu'une passerelle peut appliquer sans signature, car elle arrête. Référence :
`crypto.command_canonical` et `crypto.verify_agent_signature`. *Vérification côté passerelle à écrire avec le modèle de batterie
retenu (D255).*

**Coupure côté batterie** : la passerelle de la batterie doit arrêter d'elle-même une charge ou une décharge dont la
commande n'est pas renouvelée (durée de la commande dépassée) ; l'agent revérifie SEC2 et SEC3 toutes les 10 secondes,
mais un agent arrêté net ne peut plus rien couper. Le BMS reste le dernier rempart. Le broker n'écoute jamais sur l'interface WAN ou VPN.
*Non vérifié sur boîtier* ; la recette a utilisé `amqtt` sans TLS sur la boucle locale.

## 5. Équipements

- **Shelly Plug Gen2** : MQTT activé, `mqtt_id` = préfixe de topic du Shelly, statut `status/switch:0` (ou `em:0`,
  `pm1:0`). Format lu : `apower`, `voltage`, `current`, `pf`, `aenergy.total` (documentation Shelly Gen2) ; *non vérifié
  sur prise réelle*.
- **Commandes vers les prises (test, recherche, Wi-Fi)** : l'agent n'interroge que le réseau privé du site et ne suit
  aucune redirection HTTP d'un appareil (une réponse 3xx est traitée comme une absence de réponse). **Limite Shelly Gen1** :
  l'API Gen1 (`/settings/sta`) n'accepte le mot de passe Wi-Fi que dans l'URL d'une requête HTTP en clair ; il est donc
  lisible par tout poste du réseau local pendant l'envoi (jamais journalisé par l'agent). Préférer une prise Gen2 (RPC
  `WiFi.SetConfig`, corps de requête) ou effectuer l'appairage Gen1 sur un réseau d'installation isolé, puis changer le
  mot de passe du réseau d'appairage.
- **PowerLogic (Modbus)** : `{"device_id": N, "kind": "powerlogic_modbus", "modbus": {"transport": "tcp", "host": "…", "port": 502,
  "unit_id": 1, "profile": "pm5000"}}` (ou `"transport": "rtu", "serial_port": "/dev/ttyUSB1", "baudrate": 19200, "parity": "E"`).
  Lecture toutes les 60 s ; le profil `pm5000` reprend la table publique PM5000 (courant et tension moyens, puissance active
  totale, facteur de puissance, énergie active soutirée) et **reste à confirmer sur la référence installée** ; une table
  propre au modèle se déclare par `"registers": [{"data_type": "power_w", "address": 3059, "fmt": "float32", "scale": 1000}, …]`.
  *Non vérifié sur centrale réelle* (serveur Modbus simulé en recette).
- **Linky (TIC)** : module de lecture TIC (µTIC, USB) ; `{"device_id": N, "kind": "linky_tic", "tic": {"port": "/dev/ttyUSB0",
  "mode": "standard", "meter_id": "adresse ADSC"}}` (`historique` pour un compteur resté en mode historique). Index d'énergie
  soutirée (et injectée), courant, tension, puissance apparente ; `meter_id` refuse la trame d'un autre compteur. L'utilisateur
  du service doit appartenir au groupe `dialout`. *Non vérifié sur compteur réel* (pseudo-terminal en recette).
- **Batterie Jackery** : aucune API de pilotage publique vérifiée. L'agent publie `<command_prefix>/{charge,discharge,standby}`
  et lit `status_topic` au format JSON H2S (`soc`, `power_charge_w`, `power_discharge_w`, `voltage_v`, `current_a`, `temperature_c`, `timestamp`) : une passerelle propre au modèle doit
  traduire (D255).

## 6. Révocation et remplacement

Boîtier perdu ou volé : écran **Agents locaux** → **Révoquer**, avec motif. Le cloud refuse la clé dès la requête
suivante. Remplacement : nouveau code d'enrôlement sur le même site ; l'ancien agent actif est révoqué à l'inscription du nouveau.
